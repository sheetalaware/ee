import { TestBed, inject } from '@angular/core/testing';

import { AuthGuardService } from './auth-guard.service';
import {AuthService} from '../index';
import { RouterTestingModule } from '@angular/router/testing';
import { RoleGuardService } from "./role-guard.service";
describe('AuthGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports : [RouterTestingModule],
      providers: [AuthGuardService,AuthService]
    });
  });

  it('should be created', inject([AuthGuardService], (service: AuthGuardService) => {
    expect(service).toBeTruthy();
  }));
   it('should return boolean can-activate',  inject([AuthGuardService], (service: AuthGuardService) => {
    expect(service.canActivate()).toBe(false);
  }));
});
