export const endPoints = {
    //baseUrl: 'http://172.26.21.35:8080/api/rapid-pull',
    //baseUrl : 'http://172.26.21.100:8094',
    //baseUrl : 'http://localhost:8094',
    baseUrl : 'http://xipl0626-vm:8090',
    //baseUrl : 'http://172.30.30.20:8096',
    //baseUrl : 'http://172.26.21.106:8094',
    urlPath: { 
        issuers : 'api/issuers',
        api : 'api',
        login : 'api/home',
        salesOrder : 'api/sales-orders',
        reassignSo : 'api/reassign-sales-orders',
        productionOrders : 'api/production-orders',
        reassignPo : 'api/reassign-production-orders',
        satellites : 'api/satellites',
        clientMachines : 'api/client-machines',
        productionItems : 'api/reassign-production-items'
        //loginApi: '/auth/login',
    }
};

/**
 * Usage : let URL =`${endPoints.baseUrl}${endPoints.urlPath.refData}`;
 */
