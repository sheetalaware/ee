import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PodetailsComponent } from './podetails.component';
import { Component, OnInit, ViewChildren, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { POdetailsService } from './podetails.service';
import { HttpClientModule } from '@angular/common/http';

import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { Observable } from 'rxjs/Rx';
import { SearchfieldComponent, CardsComponent } from "../index";

import { UtilsService, LoaderService } from "../../services/index";
import { DialogService } from "../modal-dialog/modal-dialog.service";
import { BsModalService, ModalModule } from "ngx-bootstrap";
import { ArrayFilterPipe } from "../../pipes/index";
describe('PodetailsComponent', () => {
  let component: PodetailsComponent;
  let fixture: ComponentFixture<PodetailsComponent>;

  class MockRouter {
    navigate = jasmine.createSpy('navigate');
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, FormsModule, ReactiveFormsModule, RouterTestingModule,
      ModalModule.forRoot()
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [PodetailsComponent, SearchfieldComponent, ArrayFilterPipe, CardsComponent],
      providers: [POdetailsService, DialogService,UtilsService, ArrayFilterPipe,BsModalService, LoaderService, { provide: ActivatedRoute, useValue: { 'params': Observable.from([{ 'id': 1 }]) } }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PodetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should return filtered array', () => {
    component.cardDetails = [{ pan: 'XXXX1234' }, { pan: 'XXXX3333' }];
    component.performFilter('1234');
    expect(component.filteredCards.length).toBe(1);
  });
  it('should open redirect Page for redirection',() => {
    component.redirectPI({});
    expect(component.redirectView).toBeFalsy();
  });
  it('should return pan item with selected record',() => {
    component.cardDetails = [{ pan: 'XXXX1234', selected : true }, { pan: 'XXXX3333' }];
    component.performFilter('1234');
    let result = component.fetchSelectedPIS();
    expect(result.length).toBe(1);
  });
  it('should return record selected',() => {
    component.cardDetails = [{ pan: 'XXXX1234', selected : true,productionItemId : 1 }, { pan: 'XXXX3333',productionItemId : 2 }];
    component.recordSelected({productionItemId : 2});
    expect(component.cardDetails[1].selected).toBeTruthy();
  })
  it('should redirect',()=>{
    component.redirectTrigger();
    expect(component.redirectView).toBeFalsy();
  })
  it('should redirect to production Order View',() => {
    component.onCancel();
    expect(component.redirectView).toBeFalsy();
  })
});
