import { Injectable } from '@angular/core';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { endPoints } from '../../../shared/constants/index';

@Injectable()
export class OrderListService {
  private _config: any;
  private _salesOrder: any;
  /**
   * get the config 
   */
  get config(): any {
    return this._config;
  }
  /**
   * Will set the config
   */
  set config(cfg: any) {
    this._config = cfg;
  }
  /**
   * Get the saled 
   */
  get salesOrder(): any {
    return this._salesOrder;
  }
  set salesOrder(orders: any) {
    this._salesOrder = orders;
  }
  constructor(private http: HttpClient) { }

  /**
   * getOrderList this function will fetch the list of orders. (Sales/ Production)
   */
  public getOrderList = (method): Observable<any> => {
    if (method === "GET") {
      return this.http.get(this.config.url);
    } else {
      let params: any = {};
      let po: string = this.salesOrder ? this.salesOrder : '';
      params['salesOrderIds'] = po;
      return this.http.post(this.config.url, params)
    }
  }
  /**
   * this function will trigger generate Production 
   */
  public generateProductionOrder = (param: any, url: string): Observable<any> => {
    return this.http.post(url, param);
  }
}
