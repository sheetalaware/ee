import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { endPoints } from "../../constants/index";

@Injectable()
export class POdetailsService {

    private jsonUrl = `${endPoints.baseUrl}/${endPoints.urlPath.productionOrders}/`;

    constructor(private _http: HttpClient) { }

    getCards(params): Observable<any> {
        return this._http.get(this.jsonUrl + params)
            .map(response => response);
    }
    /**
     * personalize production
     */
    public personalizeProduction = (id:string) => {
        let url = `${endPoints.baseUrl}/${endPoints.urlPath.productionOrders}/${id}/personalize`
        return this._http.patch(url,{});
    }

}
