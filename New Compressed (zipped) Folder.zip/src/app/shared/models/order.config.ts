export class OrderConfig {
    public beforeRedirect : string;
    public redirect : string = '';
    public gridConfigs : any;
    public url : any = '';
    public globalPlaceholder : any ='';
    public perPageArray : any = [];
    public filterForm : any = [];
    public mobileOrderList : any = [];
    public checkboxDisable : Function;
    public method : string;
    constructor(beforeRedirect,globalPlaceholder,redirect,perPageArray,filterForm,gridConfigs,url,mobileOrderList,checkboxDisable,method) {
        this.beforeRedirect = beforeRedirect;
        this.redirect = redirect;
        this.gridConfigs = gridConfigs;
        this.url = url;
        this.globalPlaceholder = globalPlaceholder;
        this.perPageArray = perPageArray;
        this.filterForm = filterForm;
        this.mobileOrderList = mobileOrderList;
        this.checkboxDisable = checkboxDisable;
        this.method = method;
    }
}
