import { Injectable } from '@angular/core';

@Injectable()
export class AuthService {
  public _role: string;
  public _clientMachine: string;
  public _satellite: string;
  public _issuer: string;
  public _token: string;
  public _username : string;
  /**
   * get role of the logged in user 
   * 
   */
  get role(): string {
    return this._role;
  }
  /**
   * Set role of the logged in user
   * set role('OPM')
   */
  set role(role: string) {
    this._role = role;
  }
  /**
   * get Client Machine of the logged in user
   */
  get clientMachine(): string {
    return this._clientMachine;
  }
  /**
   * set client machine of the given user
   */
  set clientMachine(cm: string) {
    this._clientMachine = cm;
  }
  /**
   * get Satellite of the give user
   */
  get satellite(): string {
    return this._satellite;
  }
  /**
   * set satellites for a give user
   * 
   */
  set satellite(s: string) {
    this._satellite = s;
  }
  /**
   * get issuer logo for a given satellite
   */
  get issuer(): string {
    return this._issuer;
  }
  /**
   * Set issuer logo for a given satellite
   */
  set issuer(issuer: string) {
    this._issuer = issuer;
  }
  /**
   * Get token for the logged in user
   */
  get token(): string {
    return this._token;
  }
  /**
   * Set token for the looged in user
   */
  set token(token: string) {
    this._token = token;
  }
  get username() : string {
    return this._username;
  }
  set username(name :string){
    this._username = name;
  }
  constructor() { }
  /**
   * isAuthenticated to check wether the user is authenticated to use the applicaiton
   *  */
  public isAuthenticated = () => {
    this.token = this.token ? this.token : localStorage.getItem('csri-token') ? localStorage.getItem('csri-token') : null;
    return this.token ? true : false;
  }
  /**
   * save user token in local storage 
   */
  public saveUserToken = (item: any,name :string) => {
    localStorage.setItem('csri-token', item);
    localStorage.setItem('csri-username',name);
    this.token = item;
  }
  /**
   * remove user token from local storage
   */
  public removeUser = () => {
    localStorage.removeItem('csri-token');
    localStorage.removeItem('csri-username');
    this.token = null;
    this.clientMachine = null;
    this.issuer = null;
    this.role = null;
    this.satellite = null;
    this.username = null;
  }
  /**
   * set user info in our service so that we can use it in our applciation
   */
  public userInfo = (data: any) => {
    this.clientMachine = data.headers.get('current_client_machine');
    this.issuer = data.headers.get("issuer");
    this.role = data.headers.get('role');
    this.satellite = data.headers.get('current_satellite');

  }
}
