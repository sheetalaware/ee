import { Component, OnInit } from '@angular/core';
import { OrderConfig, OrderFiltersConfig, GridConfig, MOrderConfig } from '../../shared/models/index';
import { endPoints } from '../../shared/constants/index';
import { OrderListService } from '../../shared/services/index';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { TranslateService } from "@ngx-translate/core";
@Component({
  selector: 'app-production-order',
  templateUrl: './production-order.component.html',
  styleUrls: ['./production-order.component.scss']
})
export class ProductionOrderComponent implements OnInit {
  public receivedCellid: any;
  public redirectView: boolean = false;
  public redirectProductionOrder: boolean = false;
  public refeshData: boolean = false;
  public redirectSelectedArray: any = [];
  public defaultFilter: any = "status";
  public selectedKey: string = "orderId";
  public defaultFilterValue = "queued";
  public responseKey = "productionOrders";
  public selectedString = "Selected Production Orders";
  public redirectHeaderText = "Redirect Production Orders";
  public parentCmp: string = "productionorder";
  public method: string = "GET";
  public isPersionalize: boolean = false;
  public clientMachineId : any = [];
  constructor(private _translate:TranslateService,private listService: OrderListService, private _location: Location, private router: Router) { }

  ngOnInit() {
    this.listService.config = this.productionConfig();
  }

  /**
   * productionConfig
   */
  public productionConfig = (): any => {
    let config: any = {};
    config = new OrderConfig('Personalize',
      this._translate.instant('search'),
      'Redirect',
      [10, 20, 30],
      [new OrderFiltersConfig('I', 'text', [], 'form-group  col-sm-3 col-md-4 col-lg-2', this._translate.instant('PRODUCTION_ORDER_PAGE.production_order_id'),  this._translate.instant('PRODUCTION_ORDER_PAGE.poid'), 'orderId', 'form-control'),
      new OrderFiltersConfig('I', 'number', [], 'form-group col-sm-3 col-md-4 col-lg-2', this._translate.instant('PRODUCTION_ORDER_PAGE.volume'), this._translate.instant('PRODUCTION_ORDER_PAGE.from'), 'volumeFrom', 'form-control'),
      new OrderFiltersConfig('I', 'number', [], 'form-group col-sm-3 col-md-4 col-lg-2', '', 'to', 'volumeTo', 'form-control'),
      new OrderFiltersConfig('I', 'text', [], 'form-group col-sm-3 col-md-4 col-lg-2',  this._translate.instant('PRODUCTION_ORDER_PAGE.delivery_date'), 'from', 'fromDate', 'form-control'),
      new OrderFiltersConfig('I', 'text', [], 'form-group col-sm-3 col-md-4 col-lg-2', '', 'to', 'toDate', 'form-control'),
      new OrderFiltersConfig('S', 'options', this.fetchStatusOptions(), 'form-group col-sm-3 col-md-4 col-lg-2', this._translate.instant('PRODUCTION_ORDER_PAGE.status'), 'status', 'status', 'form-control')
      ],
      [new GridConfig('orderId', this._translate.instant('PRODUCTION_ORDER_PAGE.production_order_id'), true, true),
      new GridConfig('volume', this._translate.instant('PRODUCTION_ORDER_PAGE.volume'), true, false),
      new GridConfig('deliveryDate', this._translate.instant('PRODUCTION_ORDER_PAGE.delivery_date'), true, false),
      new GridConfig('status', this._translate.instant('PRODUCTION_ORDER_PAGE.status_of_order'), true, false)],
      this.fetchUrlForProductionOrder(),
      [new MOrderConfig('orderId', 'ID',true), new MOrderConfig('status', 'Status',false), new MOrderConfig('volume', 'Volume',false), new MOrderConfig('deliveryDate', 'Delivery Date',false)],
      (...arg) => { return arg[0].status.toLowerCase() != "queued" && arg[0].status.toLowerCase() != "failed" },
      this.method
    );
    return config;
  }
  /**
   * fetchUrlForProductionOrder
   */
  public fetchUrlForProductionOrder = (): string => {
    
    let url: string = `${endPoints.baseUrl}/${endPoints.urlPath.productionOrders}`;
    this.method = "GET";
    if (this.listService.salesOrder && this.listService.salesOrder.length > 0) {
      this.method = "POST";
      this.defaultFilter = false;
    }
    return url;
  }
  /**
   * onRedirect
   */
  public onRedirect = (selectedEl: any) => {
    this.redirectView = true;
    this.redirectProductionOrder = false;
    this.redirectSelectedArray = selectedEl;
    let clientMachine : any = [];
    this.redirectSelectedArray.forEach((item) => {
      clientMachine.push(item.clientManagerId);
    });
    this.clientMachineId = Array.from(new Set(clientMachine));
  }

  public onCommonLoad(cell_id) {
    this.receivedCellid = cell_id;
    this.redirectView = false;
    this.redirectProductionOrder = true;
    this.isPersionalize = true;
  }

  public getPersionalizeselectedId(cell_id: any) {
    this.receivedCellid = cell_id;
    this.redirectView = false;
    this.redirectProductionOrder = true;
    this.isPersionalize = false;
  }

  /**
   * onCancel 
   */
  public onCancel = () => {
    this.redirectView = false;
  }
  /**
   * redirectTrigger
   */
  public redirectTrigger = (e) => {
    
    this.redirectView = false;
    this.refeshData = !this.refeshData;
   
  }

  public redirectPOEvenCheckboxLoad(cell_id: any) {
  }

  /**
   * fetchStatusOptions
   */
  public fetchStatusOptions = (): any => {
    let result: any = [];
    result.push({
      key: this._translate.instant('PRODUCTION_ORDER_PAGE.created_key'), value: this._translate.instant('PRODUCTION_ORDER_PAGE.created')
    }, {
        key: this._translate.instant('PRODUCTION_ORDER_PAGE.queued_key'), value: this._translate.instant('PRODUCTION_ORDER_PAGE.queued')
      }, {
        key: this._translate.instant('PRODUCTION_ORDER_PAGE.under_process_key'), value: this._translate.instant('PRODUCTION_ORDER_PAGE.under_process')
      }, {
        key: this._translate.instant('PRODUCTION_ORDER_PAGE.completed_key'), value: this._translate.instant('PRODUCTION_ORDER_PAGE.completed')
      }, {
        key: this._translate.instant('PRODUCTION_ORDER_PAGE.failed_key'), value: this._translate.instant('PRODUCTION_ORDER_PAGE.failed')
      }, {
        key: this._translate.instant('PRODUCTION_ORDER_PAGE.shipped_key'), value: this._translate.instant('PRODUCTION_ORDER_PAGE.shipped')
      });
    return result;

  }
  /**
   * onCancelPoDetails
   */
  public onCancelPoDetails = () => {
    this.redirectProductionOrder=false;
  }
  public showProductionOrder = (e : any) => {
    
    this.redirectProductionOrder=false;
    if(e.id != ''){
     this.listService.salesOrder = [];
      this.listService.config = this.productionConfig();
    }
    this.refeshData = !this.refeshData;
  }
}
