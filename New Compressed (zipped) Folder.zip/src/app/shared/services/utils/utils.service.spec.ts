import { TestBed, inject } from '@angular/core/testing';

import { UtilsService } from './utils.service';

describe('UtilsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UtilsService]
    });
  });

  it('should be created', inject([UtilsService], (service: UtilsService) => {
    expect(service).toBeTruthy();
  }));
  it('should sort date in ascending order', inject([UtilsService], (service: UtilsService) => {
    let result = service.sortDate({date : '22/02/2018'},{date : '02/06/2018'},'date',1);
    expect(result).toBe(-1);
  }));

  it('should sort date in descending order', inject([UtilsService], (service: UtilsService) => {
    let result = service.sortDate({date : '22/06/2018'},{date : '02/06/2018'},'date',1);
    expect(result).toBe(1);
  }));

  it('should sort date return 0', inject([UtilsService], (service: UtilsService) => {
    let result = service.sortDate({date : '22/06/2018'},{date : '22/06/2018'},'date',1);
    expect(result).toBe(0);
  }));
});
