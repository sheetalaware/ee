import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import {AuthService ,OrderListService} from '../../services/index';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  isNavbarIcon : any;
  constructor(private _location: Location, private auth : AuthService,private orderListService : OrderListService) { }
  
  ngOnInit() {
     this.isNavbarIcon = this._location.path();
  }
  /**
   * enableSidebar
   */
  public enableSidebarOperationManager = (): boolean => {
    let role = this.auth && this.auth.role ? this.auth.role.toLocaleLowerCase() : '';
    return this._location.path() != '/login' && role === 'opm';
  }
  /**
   * enableSidebarOperationManagerOrPs
   */
  public enableSidebarOperationManagerOrPs = (): boolean =>  {
    let role = this.auth && this.auth.role ? this.auth.role.toLocaleLowerCase() : '';
    return this._location.path() != '/login' && (role === 'opm' || role === 'ps');
  }
  /**
   * sidebarClick
   */
  public sidebarClick = () => {
    this.orderListService.salesOrder = [];
  }
}
