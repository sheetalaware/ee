import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RoleGuardService as RoleGuard } from './shared/services/guard/role-guard.service';
import { SalesOrderComponent, ProductionOrderComponent, LoginComponent} from './pages/index';

const routes: Routes = [{
  path: '',
  redirectTo: '/login',
  pathMatch: 'full'
}, {
  path: 'login',
  component: LoginComponent
}, {
  path: 'sales-order',
  component: SalesOrderComponent,
  canActivate: [RoleGuard],
  data: {
    expectedRole: ['OPM']
  }
}, {
  path: 'production-order',
  component: ProductionOrderComponent,
  canActivate: [RoleGuard],
  data: {
    expectedRole: ['OPM','PS']
  }
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }

