export * from './podetails.component';
export * from './podetails.service';