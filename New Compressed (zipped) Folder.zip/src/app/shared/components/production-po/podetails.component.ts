import { Component, OnInit, ViewChildren, Input, Output, EventEmitter } from '@angular/core';
import { POdetailsService } from './podetails.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UtilsService, LoaderService } from "../../services/index";

import { DialogService } from '../modal-dialog/modal-dialog.service';
import { ArrayFilterPipe } from "../../pipes/index";
@Component({
  selector: 'app-podetails',
  templateUrl: './podetails.component.html',
  styleUrls: ['./podetails.component.scss']
})
export class PodetailsComponent implements OnInit {
  @Output() onCancelPoDetails = new EventEmitter<any>();
  @Output() showProductionOrder = new EventEmitter<any>();
  redirectBack: any;
  public podetails: any;
  public personalizeButton: string = "Personalize All"
  public personalizeButtonPO: string = "Personalize"
  public redirectButton: string = "Redirect"
  public cardDetails: any;
  public selectedCards: any;
  public poCardClass: string = "card po-cards";
  public masterButtonClass: string = "btn-master";
  public passProgressStatus: string = "40%";
  public secondaryButtonClass: string = "btn-secondary";
  filteredCards = this.cardDetails;
  public redirectSelectedArray: any;
  public redirectDisabled: boolean = true;
  public selectedKey: string = 'pan';
  public searchplaceholder: string = "Search using PAN #";
  public redirectView: boolean = false;
  public redirectHeaderText: string = "Redirect Production Items";
  public selectedString: string = "Selected Production Items";
  public isCheckBox: boolean = true;
  public parentCmp: string = "podetails";
  public openPIElementsById: any;
  private showHidePersonalItems = true;
  public clientMachineId : any = []; 
  @Input('cellId') cellId: any
  @Input('isPersionalizeSet') isPersionalizeSet: any;
  public filterDataIndex : string = "productionItemId";

  performFilter(value): any {
    value = value.toLocaleLowerCase();
    this.filteredCards = this.utils.filterArray(this.cardDetails, value, ['pan'], 'or', true);
  }
  constructor(private dialogService: DialogService, private podetailsService: POdetailsService, private utils: UtilsService, public cardpipe: ArrayFilterPipe, private route: ActivatedRoute, public loadingService: LoaderService, private router: Router) {
  }

  ngOnInit() {
    this.triggerPoDetails(this.cellId)

  }

  togglePersonalizeItems(index: any) {
    this.showHidePersonalItems = !this.showHidePersonalItems;
    !this.showHidePersonalItems ? document.getElementById('showHide').innerHTML = "Hide all PI's" : document.getElementById('showHide').innerHTML = "Show all PI's"
  }
  /**
   * triggerPoDetails
   */
  public triggerPoDetails = (params) => {
    this.podetailsService.getCards(params)
      .subscribe(cards => {
        this.cardDetails = cards.productionItems;
        this.podetails = cards;
        this.filteredCards = this.cardDetails;
        this.clientMachineId.push(cards.clientMachine);
        this.loadingService.hide();
      });
  }
  public redirectPI = (e: any) => {
    this.redirectSelectedArray = this.fetchSelectedPIS();
    this.redirectView = (this.redirectSelectedArray.length > 0) ? true : false;
  }
  /**
   * fetchSelectedPIS
   */
  public fetchSelectedPIS = (): any => {
    let result: any = [];
    let ary: any = this.filteredCards ? this.filteredCards : [];
    result = this.utils.filterArray(ary, 'true', ['selected'], 'or', true);
    this.selectedCards = result;
    return result;
  }
  /**
   * recordSelected
   */
  public recordSelected = (item: any) => {
    let index = this.utils.fetchObjectFromAnArray(this.cardDetails, item, 'productionItemId');
    this.cardDetails[index].selected = this.cardDetails[index].selected ? !this.cardDetails[index].selected : true;
    this.redirectDisabled = this.fetchSelectedPIS().length > 0 ? false : true;
  }
  /**
   * redirectTrigger
   */
  public redirectTrigger = () => {
    this.redirectView = false;
    this.showProductionOrder.emit({id:this.podetails.productionOrderId});
  }
  public onCancel = () => {
    this.redirectView = false;
  }
  /**
   * personaliseAll
   */
  public personaliseAll = () => {
    this.isPersionalizeSet = false;
  }
  public personalise = (e) => {
    this.podetailsService.personalizeProduction(this.podetails.productionOrderId).subscribe((success) => {
      this.loadingService.hide();
      this.showProductionOrder.emit({id:this.podetails.productionOrderId});
      this.openModal(success);
    }, (err) => {

    });
    // this.router.navigate(['po-personalization',this.podetails.productionOrderId]);
  }

  public onBack = () => {
    (this.isPersionalizeSet) ? this.onCancelPoDetails.emit() : this.isPersionalizeSet = !this.isPersionalizeSet;
  }
  public openModal = (success) => {
    this.dialogService.showDialog(true, success.message, "Ok", () => { }, "", () => { });
  }

  onBackButton(value: any) {
    this.isPersionalizeSet = value;
    (this.isPersionalizeSet) ? this.onCancelPoDetails.emit() : this.isPersionalizeSet = !this.isPersionalizeSet;
  }
/**
 * calculateNoOfDays
 */
public calculateNoOfDays = (date : any) : string => {
  let result : string;
  let noOfDays : number = (date) ? this.utils.toFindTheDifferenceBetweenDays(new Date(),date) : 0;
  result = (noOfDays > 1) ? `${noOfDays} days` : `${noOfDays} day`;
  return result;
}

}
