import { TestBed, inject } from '@angular/core/testing';

import { RoleGuardService } from './role-guard.service';
import { AuthService, LoginService } from '../index';

import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('RoleGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [RoleGuardService, AuthService, LoginService, HttpClient, HttpHandler]
    });
  });

  it('should be created', inject([RoleGuardService], (service: RoleGuardService) => {
    expect(service).toBeTruthy();
  }));

it('should return boolean can-activate',  inject([RoleGuardService], (service: RoleGuardService) => {

    
  }));
 
});
