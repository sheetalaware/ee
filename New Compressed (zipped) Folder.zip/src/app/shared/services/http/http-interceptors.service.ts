import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { LoaderService } from '../loader/loader.service';
import { AuthService } from '../auth/auth.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ModalComponent } from '../../components/index';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { ModalDialogComponent } from '../../components/modal-dialog/modal-dialog.component';
@Injectable()
export class HttpInterceptorsService implements HttpInterceptor {

    public modalRef: BsModalRef;
    constructor(private loaderService: LoaderService, private auth: AuthService, private modalService: BsModalService) { }
    /**
     * This method will add the token with all the http  request headers
     * @param req 
     * @param token 
     */
    addToken(req: HttpRequest<any>, token: string): HttpRequest<any> {
        return req.clone({ setHeaders: { Authorization: 'Basic ' + token } })
    }
    /**
     * This mehtod will help us to habdle all the http exception handling at one place as well all the common headers we can add it from this function
     * 
     * @param req 
     * @param next 
     */
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.loaderService.show();
        return next.handle(this.addToken(req, this.auth.token))
            .catch(error => {
                this.loaderService.hide();
                if (error instanceof HttpErrorResponse) {
                    switch ((<HttpErrorResponse>error).status) {
                        case 403:
                            return this.handleError({message : 'Invalid User Credentials'}, false);
                        case 401:
                            return this.handleError({message : 'Invalid User Credentials'}, false);
                        default: return this.handleError(error, false)
                    }
                } else {
                    return Observable.throw(error);
                }
            }).do((res: Response) => {
            });
    }
    /**
     * Handle error for the http call is handled with the help of this function 
     */
    handleError = (err: any, logOut: any) => {
        if (logOut) {
            //this.loginService.logOutUser();
            // this.showModal('Session Expired','Error');
        }
        let msg = err && err.error && err.error.message ? err.error.message : err && err.message ? err.message : 'Service Error Occured';
        this.showModal(msg, 'Error');
        throw new Error(err);
    }
    /**
     * This method will show modal popup to disply error received from http calls
     */
    showModal = (message, headerText) => {
        setTimeout(() => {
            let bsModalRef = this.modalService.show(ModalDialogComponent, { animated: true, keyboard: false, backdrop: true, ignoreBackdropClick: true });
            bsModalRef.content.successError = false;
            bsModalRef.content.message = message;
            bsModalRef.content.successButtonText = "Ok";
            bsModalRef.content.onSuccess = () => {
                bsModalRef.hide();
            }
        }, 500);
    }
}