import { Injectable } from '@angular/core';
import {
  Router,
  CanActivate,
  ActivatedRouteSnapshot
} from '@angular/router';
import { Observable } from 'rxjs/Observable'
import { AuthService } from '../auth/auth.service';
import { LoginService } from '../login/login.service';

@Injectable()
export class RoleGuardService implements CanActivate {
  private result: Observable<boolean>;
  private canActivateRoute: boolean;
  constructor(public auth: AuthService, public router: Router, public loginService: LoginService) { }
  /**
   * For the component to be loaded on a particular url caActivate method is called which checks whether the user is authenticated
   * to access the url
   * it return boolean
   */
  canActivate = (route: ActivatedRouteSnapshot): Observable<boolean> => {
    
    this.result = new Observable(observer => {
      this.checkWhetherUserEligible(route, observer);
    });
    return this.result.map(res => {
      if (!res) {
        this.router.navigate(['login']);
      }
      return res;
    });
  }
  /**
   * mehtod will check whether the user is eligible to use the appication .
   * it will check whether the user token is present in local storage to access it.
   */
  public checkWhetherUserEligible = (route, observer): boolean => {
    let result = true;
    if (!this.auth.isAuthenticated()) {
      observer.next(false);
    } else if (this.auth.token && this.auth.role) {
      observer.next(this.checkWhetherRoleExists(route.data.expectedRole));
    } else {
      this.loginService.logIn().subscribe(res => {
        this.auth.userInfo(res);
        observer.next(this.checkWhetherRoleExists(route.data.expectedRole));
      }, err => {
        observer.next(false);
      });
    }
    return result;
  }
  /**
   * checkWhetherRoleExists mehtod will check whether the given role is matching wih the role assigned to the user
   * it will return true or false
   */
  public checkWhetherRoleExists = (expectedRole: any): boolean => {
    let result = false;
    expectedRole.forEach(element => {
      (this.auth.role && element.toLocaleLowerCase() === this.auth.role.toLocaleLowerCase()) ? result = true : '';
    });
    return result;
  }
}
