import { async, ComponentFixture, TestBed,inject } from '@angular/core/testing';

import { ProductionOrderComponent } from './production-order.component';
import { OrderListComponent, SearchfieldComponent, ButtonComponent, RemovableCardComponent, FilterPanelComponent } from '../../shared/components/index';
import { ReassignComponent } from '../../shared/components/reassign/reassign.component'; 
import { FormGroup, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BsDatepickerModule, BsModalService, ModalModule } from 'ngx-bootstrap';
import {OrderListService,UtilsService} from '../../shared/services/index';
import { LoaderService } from '../../shared/services';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { DialogService } from "../../shared/components/modal-dialog/modal-dialog.service";
import { TranslateService } from "@ngx-translate/core";
import { TranslateLoader } from "@ngx-translate/core";
import { HttpLoaderFactory } from "../../app.module";
import { TranslateModule } from "@ngx-translate/core";
describe('ProductionOrderComponent', () => {
  let component: ProductionOrderComponent;
  let fixture: ComponentFixture<ProductionOrderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, BsDatepickerModule.forRoot(),RouterTestingModule,HttpClientModule,ModalModule.forRoot(),TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactory,
                deps: [HttpClient]
            }
        })],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers : [OrderListService,UtilsService, LoaderService,DialogService,BsModalService,TranslateService],
      declarations: [ProductionOrderComponent, FilterPanelComponent, OrderListComponent, ReassignComponent, SearchfieldComponent, ButtonComponent, RemovableCardComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductionOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should show production order' ,() => {
    component.redirectTrigger();
    expect(component.redirectView).toBeFalsy();
  });
  it('should show production order on cancel',() =>{
    component.onCancel();
    expect(component.redirectView).toBeFalsy();
  });
  it('should give us the list of selected element onclick of redirect',() => {
    component.onRedirect([{orderId : 2}]);
    expect(component.redirectSelectedArray.length).toBe(1);
  })
  it('fetch Url form production order',inject([OrderListService],( service : OrderListService) =>{
    service.salesOrder = [1,2];
    let result = component.fetchUrlForProductionOrder();
    expect(component.method).toBe('POST');
  }));
});
