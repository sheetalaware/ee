import { TestBed, inject } from '@angular/core/testing';

import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { DialogService } from "./modal-dialog.service";
import { BsModalService, ModalModule } from "ngx-bootstrap";
import { ModalDialogComponent } from "./modal-dialog.component";

describe('DialogService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[ModalModule.forRoot()],
      providers: [DialogService,BsModalService]
    });
  });

  it('should be created', inject([DialogService], (service: DialogService) => {
    expect(service).toBeTruthy();
  }));
  it('should show modal', inject([DialogService], (service: DialogService,modalService:BsModalService) => {
    //  modalService.show(ModalDialogComponent,{});
  }));
});
