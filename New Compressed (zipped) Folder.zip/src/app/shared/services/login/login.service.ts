import { Injectable } from '@angular/core';

import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import {endPoints} from '../../constants/index';
import {Headers,RequestOptions} from '@angular/http';
export const contentHeaders = new Headers();
@Injectable()
export class LoginService {
  
  constructor(private http : HttpClient) { }
  /**
   * logIn function will make an api call to fetch the logged is user info
   */
  public logIn = () =>{
    let url = `${endPoints.baseUrl}/${endPoints.urlPath.login}`;
    return this.http.get(url,{observe:'response'})
  }
}
