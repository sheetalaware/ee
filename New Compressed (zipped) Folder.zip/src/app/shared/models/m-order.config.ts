export class MOrderConfig {
    public orderKey : string;
    public orderLabel : string = '';
    public enableClick : boolean ;
    constructor(orderKey,orderLabel,enableClick) {
        this.orderKey = orderKey;
        this.orderLabel = orderLabel;
        this.enableClick = enableClick;
    }
}
