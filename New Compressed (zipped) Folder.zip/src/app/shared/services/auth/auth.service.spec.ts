import { TestBed, inject } from '@angular/core/testing';

import { AuthService } from './auth.service';

describe('AuthService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthService]
    });
  });

  it('should be created', inject([AuthService], (service: AuthService) => {
    expect(service).toBeTruthy();
  }));
  it('should set the role of the user', inject([AuthService], (service: AuthService) => {
    service.role = "ps";
    expect(service.role).toBe('ps');
  }));
  it('should set the client machine',inject([AuthService], (service: AuthService) => {
    service.clientMachine = "1";
    expect(service.clientMachine).toBe('1');
  }))
  it('should set satellites',inject([AuthService], (service: AuthService) => {
    service.satellite = "1";
    expect(service.satellite).toBe('1');
  }))
  it('should set issuer',inject([AuthService], (service: AuthService) => {
    service.issuer = "1";
    expect(service.issuer).toBe('1');
  }))
  it('should set token',inject([AuthService], (service: AuthService) => {
    service.token = "18889";
    expect(service.token).toBe('18889');
  }));
  it('should return as authenticated',inject([AuthService], (service: AuthService) => {
    service.token = "18889";
    expect(service.isAuthenticated()).toBeTruthy();
  }))

  it('should save user token',inject([AuthService], (service: AuthService) => {
    service.saveUserToken('444444','Michael');
    expect(service.token).toBe('444444');
  }))
  it('should remove user',inject([AuthService], (service: AuthService) => {
    service.removeUser();
    expect(service.token).toBeNull();
  }))
});
