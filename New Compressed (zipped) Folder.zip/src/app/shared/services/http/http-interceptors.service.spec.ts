import { TestBed, inject } from '@angular/core/testing';
import { LoaderService } from '../../services/index';
import { HttpInterceptorsService } from './http-interceptors.service';
import {AuthService} from '../index';
import { BsModalService, ModalModule, BsModalRef } from "ngx-bootstrap";
import { ModalDialogComponent } from "../../components/modal-dialog/modal-dialog.component";
import { HttpRequest } from "@angular/common/http";
describe('HttpInterceptorsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpInterceptorsService,LoaderService,AuthService,BsModalService],
       imports: [ ModalModule.forRoot()]

    });
  });

  it('should be created', inject([HttpInterceptorsService], (service: HttpInterceptorsService) => {
    expect(service).toBeTruthy();
  }));
   it('should show modal', inject([HttpInterceptorsService,BsModalService], (service: HttpInterceptorsService,req:HttpRequest<any>,modalService:BsModalService,bs:BsModalRef) => {
   service.showModal('Service Error Occured', 'Error');

  //  bs = modalService.show(ModalDialogComponent,{animated:true});

  }));
  it('should handle error', inject([HttpInterceptorsService], (service: HttpInterceptorsService) => {
 //  service.handleError(,false);
  }));
 
});
