import { Injectable } from '@angular/core';
import * as moment from 'moment';
@Injectable()
export class UtilsService {

  constructor() { }
  /**
   * sort data ascending and descending
   * direction can be 1 or -1
   * property is the data Index
   * two objects to compare i.e a and b
   */
  public sort = (a: any, b: any, property: string, direction: number): number => {
    if (a[property] < b[property]) {
      return -1 * direction;
    }
    else if (a[property] > b[property]) {
      return 1 * direction;
    }
    else {
      return 0;
    }
  }
  /**
   * sortDate ascending and descending
   * direction can be 1 or -1
   * property is the data Index
   * two objects to compare i.e a and b 
   */
  public sortDate = (a: any, b: any, property: string, direction: number): any => {
    let diff = moment(a[property], 'DD/MM/YYYY').diff(moment(b[property], 'DD/MM/YYYY').startOf('day'), 'days', true);
    if (diff < 0) {
      return -1 * direction
    } else if (diff > 0) {
      return 1 * direction;
    } else {
      return 0;
    }
  }
  /**
   * sliceArray 
   * @Params : item - the array which needs to be slice
   * startIndex  - the index from which it needs to start
   * endIndex - the index till where it will end
   */
  public sliceArray = (item: any, startIndex: number, endIndex: number): any => {
    let slicedArray: any = [];
    slicedArray = item.slice(startIndex, endIndex);
    return slicedArray;
  }
  /**
   * Filter Array
   * @Params : items - the array which needs to be filtered
   * filtertext - the text in which the array needs to be filtered
   * searchIndex - the dataIndex on whihc it needs to search 
   * 
   * ([{name :'Michael'}], 'michael',['name'], 'OR/AND')
   */
  public filterArray = (items: any, filterText: string, searchIndex: any[], operator: string, like: boolean): any => {
    let filteredItems: any = [];
    filteredItems = items.filter((item: any) => {
      let result: boolean = false;
      searchIndex.forEach((obj: any) => {
        result = searchIndex.length > 1 ? this.conditionBasedOperation(item, obj, filterText, operator, result, like) : this.likeOrEqualSearch(like, String(item[obj]).toLocaleLowerCase(), filterText.toLocaleLowerCase());
      });
      return result;
    });
    return filteredItems;
  }
  /**
   * conditionBasedFilterOperation where greater / lesser /or /and is mapped to corrdeponding methods
   * it also gives us to have a like search or an exact search
   */
  public conditionBasedOperation = (item: any, obj: any, filterText: string, operator: string, result, like: boolean): any => {
    let res: any;
    switch (operator.toLocaleLowerCase()) {
      case 'or': res = result || this.likeOrEqualSearch(like, String(item[obj]).toLocaleLowerCase(), filterText.toLocaleLowerCase());
        break;
      case 'and': res = result && this.likeOrEqualSearch(like, String(item[obj]).toLocaleLowerCase(), filterText.toLocaleLowerCase());
        break;
      case 'greater': res = item[obj] > filterText;
        break;
      case 'lesser': res = item[obj] < filterText;
        break;
      case 'lesserorequalto': res = item[obj] <= filterText;
        break;
      case 'greaterorequalto': res = item[obj] >= filterText;
        break;
      case 'lesserorequaltodate': res = moment(item[obj], 'DD/MM/YYYY').diff(moment(filterText).startOf('day'), 'days', true) <= 0;
        break;
      case 'greaterorequaltodate': res = moment(item[obj], 'DD/MM/YYYY').diff(moment(filterText).startOf('day'), 'days', true) >= 0;
        break;
      default: res = result || this.likeOrEqualSearch(like, String(item[obj]).toLocaleLowerCase(), filterText.toLocaleLowerCase());
        break;
    }
    return res;
  }
  /**
   * filterArrayRangeBased 
   *   */
  public filterArrayRangeBased = (items: any, index: string, limit: any, operator: string, like: boolean): any => {
    let filteredArray: any = [];
    filteredArray = items.filter((item: any) => {
      let result: boolean;
      result = this.conditionBasedOperation(item, index, limit, operator, result, like);
      return result;
    });
    return filteredArray;
  }
  /**
   * fetchObjectFromAnArray this will return an object from an array with the help of dataindex 
   */
  public fetchObjectFromAnArray = (ary: any, obj: any, index: string): any => {
    let selectedIndex: number;
    ary.forEach((item, i) => {
      if (item[index] === obj[index]) { selectedIndex = i; }
    });
    return selectedIndex;
  }
  /**
   * returnNewArrayFromExistingArray it will return new array
   */
  public returnNewArrayFromExistingArray = (ary: any, callback: Function): any => {
    let result: any = [];
    result = ary.map(callback);
    return result;
  }
  /**
   * like search or equal search
   */
  public likeOrEqualSearch = (like: boolean, text: string, filterText: string) => {
    return (like) ? text.indexOf(filterText) != -1 : text === filterText;
  }
  /**
   * this function will give the difference between two dates
   */
  public toFindTheDifferenceBetweenDays = (startDate: any, endDate: any): number => {
    let result: number;
    result = moment(endDate, 'DD/MM/YYYY').diff(moment(startDate).startOf('day'), 'days', true);
    return result;
  }
}
