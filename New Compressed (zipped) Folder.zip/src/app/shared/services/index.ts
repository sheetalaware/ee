import {HttpInterceptorsService} from './http/http-interceptors.service';
import {OrderListService} from './order-list/order-list.service';
import { UtilsService } from "./utils/utils.service"; 
import {LoaderService} from "./loader/loader.service";
import {RoleGuardService} from "./guard/role-guard.service";
import {AuthService} from "./auth/auth.service";
import {LoginService} from './login/login.service';

export const SharedServices = [OrderListService,UtilsService,LoaderService,AuthService,RoleGuardService,LoginService];

export *  from './http/http-interceptors.service';
export * from './order-list/order-list.service';
export *  from "./utils/utils.service"; 
export *  from "./loader/loader.service";
export * from "./guard/auth-guard.service";
export *  from "./auth/auth.service";
export *  from './login/login.service';