import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalRef, ModalModule, BsModalService } from 'ngx-bootstrap';
import { AuthService, LoginService } from '../../shared/services/index';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  errorMsg: Object;
  public modalRef: BsModalRef;
  constructor(private auth: AuthService, private loginService: LoginService, private router: Router) {
  }

  ngOnInit() {
    this.loginForm = new FormGroup({
      username: new FormControl(null, Validators.required),
      password: new FormControl(null, Validators.required)
    });
  }
  /**
   * OnSubmit : It will submit form with username and password and will get the JWt token
   */
  public onSubmit = () => {
    this.auth.saveUserToken(btoa(this.loginForm.value['username'] + ':' + this.loginForm.value['password']),this.loginForm.value['username']);
    this.auth.username = this.loginForm.value['username'];
    this.loginService.logIn().subscribe((res) => {
      this.auth.userInfo(res);
      this.redirectTo()
    }, (err) => {
      this.auth.removeUser();
    });
  }
  /**
   * redirectTo
   */
  public redirectTo = () => {
    switch (this.auth.role.toLocaleLowerCase()) {
      case 'ps': this.router.navigate(['production-order']); break;
      case 'opm': this.router.navigate(['sales-order']); break;
      default: this.router.navigate(['sales-order']); break;
    }
  }
}
