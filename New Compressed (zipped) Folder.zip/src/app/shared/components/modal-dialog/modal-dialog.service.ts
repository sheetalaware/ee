import { BsModalService } from 'ngx-bootstrap/modal';
import { ModalDialogComponent } from './modal-dialog.component';
import { Injectable } from '@angular/core';

@Injectable()
export class DialogService {
  constructor(private modalService: BsModalService) { }

  showDialog(successError:boolean, message: string, successButtonText: string, successCallback : Function, cancelButtonText: string, cancelCallBack : Function) {
    let bsModalRef = this.modalService.show(ModalDialogComponent, { animated: true, keyboard: false, backdrop: true, ignoreBackdropClick: true });
    bsModalRef.content.successError = successError;
    bsModalRef.content.message = message;
    bsModalRef.content.successButtonText = successButtonText;
    bsModalRef.content.onSuccess = () => {
        bsModalRef.hide();
        successCallback();
    }
    bsModalRef.content.cancelButtonText = cancelButtonText;
    bsModalRef.content.onCancel = () => {
        bsModalRef.hide();
    }
  }
 
}