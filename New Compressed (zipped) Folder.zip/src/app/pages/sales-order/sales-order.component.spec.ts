import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesOrderComponent } from './sales-order.component';
import { OrderListComponent, SearchfieldComponent, ButtonComponent, RemovableCardComponent, FilterPanelComponent } from '../../shared/components/index';
import { ReassignComponent } from '../../shared/components/reassign/reassign.component'; 
import { FormGroup, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BsDatepickerModule } from 'ngx-bootstrap';
import {OrderListService,UtilsService} from '../../shared/services/index';
import { BsModalService } from 'ngx-bootstrap';
import {LoaderService} from '../../shared/services/index';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import {Router} from '@angular/router';
import { DialogService } from "../../shared/components/modal-dialog/modal-dialog.service";
import { TranslateService } from "@ngx-translate/core";
import { TranslateLoader } from "@ngx-translate/core";
import { HttpLoaderFactory } from "../../app.module";
import { TranslateModule } from "@ngx-translate/core";

describe('SalesOrderComponent', () => {
  let component: SalesOrderComponent;
  let fixture: ComponentFixture<SalesOrderComponent>;
  let routerStub;
  beforeEach(async(() => {
    routerStub = {
      navigate : jasmine.createSpy('/production-order')
    }
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, BsDatepickerModule.forRoot(),RouterTestingModule,HttpClientModule,TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactory,
                deps: [HttpClient]
            }
        })],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers : [OrderListService,UtilsService, BsModalService, LoaderService,DialogService,TranslateService],
      declarations: [ SalesOrderComponent,FilterPanelComponent, OrderListComponent, ReassignComponent, SearchfieldComponent, ButtonComponent, RemovableCardComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalesOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should return orderid' ,() =>{
    let result = component.fetchOrderIdFromSelected({orderId : '1'},1);
    expect(result).toBe('1');
  });
  it('shoould redirect production order page',() => {
    component.personalizPO([{orderId : '4'},{orderId : '3'},{orderId : '2'}]);
  });
  it('should return  to PO list  page after triggering the redirect functionality' , () =>{
    component.redirectTrigger();
    expect(component.redirectView).toBe(false);
  });
  it('should return to PO list page after cancelling reassign' , () => {
    component.onCancel();
    expect(component.redirectView).toBeFalsy();
  });
  it('should redirect to redirect page on click of redirect', () => {
    component.onRedirect([{orderId : 1}]);
    expect(component.redirectSelectedArray.length).toBe(1);
  })
});
