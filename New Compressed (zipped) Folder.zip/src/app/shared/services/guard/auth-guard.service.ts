import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AuthService } from '../auth/auth.service';
@Injectable()
export class AuthGuardService implements CanActivate {
  constructor(public auth: AuthService, public router: Router) {}
  /**
   * For the component to be loaded on a particular url caActivate method is called which checks whether the user is authenticated
   * to access the url
   * it return boolean
   */
  canActivate = (): boolean => {
    if (!this.auth.isAuthenticated()) {
      this.router.navigate(['login']);
      return false;
    }
    return true;
  }
}