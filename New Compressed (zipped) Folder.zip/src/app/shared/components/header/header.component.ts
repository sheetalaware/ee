import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { Location } from '@angular/common';
import { AuthService } from '../../services/index';
import { Router } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  logoUrl: string;
  isNavbarIcon: any;
  constructor(private _location: Location, private auth: AuthService, private route: Router) { }

  ngOnInit() {
    this.isNavbarIcon = this._location.path();
  }


  expandSidebar() {
    if ($(window).width() <= 767) {

      $('.side-bar-nav').toggle();
    }

    //var togglewidth = $(".side-bar-nav").width() == 90 ? "282px" : '90px';
    $('.side-bar-nav').toggleClass("menu-expand");

    $('.side-bar-nav span').toggle();

  }
  /**
   * logout
   */
  public logout = () => {
    this.auth.removeUser();
    this.route.navigate(['login']);

  }
  public dispalyHeader = (): boolean => {
    return this._location.path() != "/login";
  }
  public logoImage = () : string => {
    return `./assets/images/${this.auth.issuer}.png`;
  }
  /**
   * loggedUsername
   */
  public loggedUsername = () : string => {
    let result : string;
    result = this.auth.username ? this.auth.username : localStorage.getItem('csri-username');
    return result;
  }
}

