import { TestBed, inject, fakeAsync,tick } from '@angular/core/testing';

import { OrderListService } from './order-list.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { endPoints } from '../../constants/index';
import { Http, BaseRequestOptions, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

describe('OrderList.ServiceService', () => {
  let backend: MockBackend;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [OrderListService, HttpClient, MockBackend,HttpHandler, {
        provide: Http,
        useFactory: (backend, options) => new Http(backend, options),
        deps: [MockBackend, BaseRequestOptions]
      }]
    });
    backend = TestBed.get(MockBackend);
  });

  it('should be created', inject([OrderListService], (service: OrderListService) => {
    expect(service).toBeTruthy();
  }));
  it('should get order list', fakeAsync(inject([OrderListService], (service: OrderListService) => {

    service.salesOrder = [1, 2];
    service.config = { url: `${endPoints.baseUrl}/${endPoints.urlPath.issuers}/1/satellites/2/production-orders` };

    let response = {
      "message": "Operation was successful",
      "status": "SUCCESS",
      "salesOrders": [
        {
          "orderId": 2,
          "volume": 33,
          "deliveryDate": "02/05/2018",
          "status": "Queued"
        },
        {
          "orderId": 3,
          "volume": 0,
          "deliveryDate": "03/05/2018",
          "status": "Queued"
        },
        {
          "orderId": 1,
          "volume": 33,
          "deliveryDate": "05/05/2018",
          "status": "Queued"
        }
      ]
    };
    backend.connections.subscribe(connection => {
      connection.mockRespond(new Response(<ResponseOptions>{
        body: JSON.stringify(response)
      }));
    });
    let result = service.getOrderList('POST');
    tick();
    result.subscribe(
      (res) => {
        expect(res.salesOrder.length).toBe(3);
      },(err) => {
      }
    );
  })));
  it('should generate production order', fakeAsync(inject([OrderListService], (service: OrderListService) => {
    let response = {
      "message": "Operation was successful",
      "status": "SUCCESS",
      "productionOrders": [
        {
          "orderId": 2,
          "volume": 33,
          "deliveryDate": "02/05/2018",
          "status": "Queued"
        },
        {
          "orderId": 3,
          "volume": 0,
          "deliveryDate": "03/05/2018",
          "status": "Queued"
        },
        {
          "orderId": 1,
          "volume": 33,
          "deliveryDate": "05/05/2018",
          "status": "Queued"
        }
      ]
    };
     backend.connections.subscribe(connection => {
      connection.mockRespond(new Response(<ResponseOptions>{
        body: JSON.stringify(response)
      }));
    });
    let result = service.generateProductionOrder({ 'productionOrderIds': [2, 3] }, `${endPoints.baseUrl}/${endPoints.urlPath.issuers}/1/satellites/2/production-orders`)
    
    tick();
    result.subscribe(
      (res) => {
        expect(res.productionOrders.length).toBe(3);
      },(err) => {
      }
    );
  })));
});
