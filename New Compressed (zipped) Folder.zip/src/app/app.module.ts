import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule } from 'ngx-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import {TranslateModule, TranslateLoader} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import {HttpClient, HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
/**
 * SharedComponents from shared folder
 */
import { SharedComponents,ModalComponent , ModalDialogComponent,GridService ,ReassignService,POdetailsService,DialogService} from './shared/components/index';

/**
 * SharedService from Shared folder
 */
import { SharedServices, HttpInterceptorsService } from './shared/services/index';
/**
 * Pages Component
 */
import {PagesComponent} from './pages/index';


import { SharedFilter} from "./shared/pipes/index";


export function HttpLoaderFactory(http: HttpClient) {
    return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    AppComponent,
    SharedComponents,
    SharedFilter,
    PagesComponent,
    ModalDialogComponent
    // ProgressStatusComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactory,
                deps: [HttpClient]
            }
        }),
    BsDatepickerModule.forRoot(),
    BsDropdownModule.forRoot(),
    ModalModule.forRoot(),
 
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: HttpInterceptorsService,
    multi: true
  }, SharedServices, GridService, POdetailsService, SharedFilter, ReassignService,DialogService],
  bootstrap: [AppComponent],
  entryComponents : [ModalDialogComponent]
})
export class AppModule { }

