import { Component, OnInit, Input, Output, EventEmitter, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { ReassignService } from './reassign.service';
import { UtilsService,LoaderService,AuthService } from '../../services/index';
import {endPoints} from '../../constants/index';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ModalDialogComponent } from '../../components/modal-dialog/modal-dialog.component';
import { DialogService } from '../modal-dialog/modal-dialog.service';
@Component({
  selector: 'app-reassign',
  templateUrl: './reassign.component.html',
  styleUrls: ['./reassign.component.scss']
})
export class ReassignComponent implements OnInit {

  modalRef: BsModalRef;

  constructor(protected reassignService: ReassignService, private utils: UtilsService, private loadingService : LoaderService, private modalService: BsModalService,private dialogService: DialogService, private auth : AuthService) { }

  @Input('selectionArray') selectedArray: any;
  @Input() selectedKey : string;
  @Input() headerText: string;
  @Input() selectionText: string;
  @Input() parentCmp : string;
  @Input() selectionType : string = "radio";
  @Output() onCancelClick = new EventEmitter<any>();
  @Output() redirectTrigger = new EventEmitter<any>();
  @Input() clientMachineId : any = [];
  reassignForm: FormGroup;
  public existingSatellite : string = this.auth.satellite ? this.auth.satellite : '';
  public existingClientMachine : string = this.auth.clientMachine ? this.auth.clientMachine : '';
  public showHide: boolean = true;
  public isClientManagerRequired : boolean = false;
  public showDropdown: boolean = false;
  public satellites: any = [];
  public redirectionMedium: string = '';
  public param: any;
  public clientMachine : any;
  public clientMachineSelected : any = [];
  @Input() filterDataIndex : string;

  openModal() {
    this.dialogService.showDialog(true, "Are you sure you want to redirect?", "Redirect", ()=>{
      this.onSubmitReassign()
    }, "Cancel", ()=>{} );
  }
  
  ngOnInit() {
    this.initializeForm();
    this.fetchSatelliteInfo();
    this.isClientManagerRequired = this.isRedirectionMediumRequired();
    (this.isClientManagerRequired) ? this.fetchClientInfo() : '';
  }
  /**
   * initializeForm
   */
  public initializeForm = () => {
    this.reassignForm = new FormGroup({
      so: new FormControl(''),
      externalSatellite: new FormControl('')
    });
    this.redirectionMedium = 'satellite';
  }
  /**
   * fetchSatelliteInfo
   */
  public fetchSatelliteInfo = () => {
    this.reassignService.getSatellite().subscribe(
      (response) => {
        this.satellites = response.satellites;
        this.loadingService.hide();
      },
      (error) => {
        console.log(error)
      }
    );
  }
  /**
   * fetchClientInfo
   */
  public fetchClientInfo = () => {
    this.reassignService.getClientMachines().subscribe(
      (response) => {
        //response.clientMachines
        this.clientMachine = response.clientMachines;
        this.loadingService.hide();
      },
      (error) => {
      }
    );
  }
  checkType = () => {
    this.redirectionMedium = this.reassignForm.controls.so.value;
    this.clientMachineSelected = [];
  }

  onSubmitReassign() {
    if (this.isFormValid()) {
      let url = this.fetchPatchUrl();
      this.param = this.manipulateParam();
      this.reAssign(url);
    }

  }
  /**
   * isFormValid 
   */
  public isFormValid = (): boolean => {
    let result = false;
    result = this.fetchValueForRedirect() != '';
    return result;
  }
  /**
   * fetchValueForRedirect
   */
  public fetchValueForRedirect = (): any => {
    let result;
    switch (this.redirectionMedium.toLocaleUpperCase()) {
      case 'SATELLITE': result = this.reassignForm.controls['externalSatellite'].value; break;
      case 'CLIENT_MACHINE' : result = this.clientMachineSelected && this.clientMachineSelected.length > 0 ? this.clientMachineSelected : ''; break;
      case 'CDP': result = 'CDP'; break;
    }
    return result;
  }
  /**
   * manipulateParam
   */
  public manipulateParam = (): any => {
    let result = {};
    let medium = this.redirectionMedium.toLocaleUpperCase();
    if (medium === "SATELLITE") {
      result['satelliteId'] = this.fetchValueForRedirect();
      result['ids'] = this.toPopulateSelectedArray();
    }else if(medium === "CLIENT_MACHINE"){
      result['ids'] = this.toPopulateSelectedArray();
      result['clientMachineId'] = this.clientMachineSelected[0].id;
    }
    result['redirectOption'] = medium;
    return result;
  }
  /**
   * toPopulateSelectedArray 
   */
  public toPopulateSelectedArray = () : any => {
    let selectedOrders: any = [];
    this.selectedArray.forEach((item) => {
      selectedOrders.push(item[this.filterDataIndex]);
    });
    return selectedOrders;
  }

  /**
   * removeSelectedArray
   */
  public removeSelectedArray = (e: any, item) => {
    let index = this.utils.fetchObjectFromAnArray(this.selectedArray, item, this.filterDataIndex);
    this.selectedArray.splice(index, 1);
  }
  /**
   * onCancel
   */
  public onCancel = () => {
    this.onCancelClick.emit();
  }
  /**
   * reAssign
   */
  public reAssign = (url : string) => {
    this.reassignService.patchSoReassign(this.param,url).subscribe(
      (response) => {
        this.selectedArray = [];
        this.redirectTrigger.emit();
        this.loadingService.hide();
        this.dialogService.showDialog(true, response.message, "Ok", ()=>{}, "", ()=>{} );
      },
      (error) => {
        console.log(error);
      }
    );
  }
  /**
   * disableRedirect
   */
  public disableRedirect = () : boolean => {
    let result = true;
    result = this.selectedArray.length === 0 || this.redirectionMedium == '' || this.fetchValueForRedirect() == '';
    return result; 
  }
  /**
   * showHideIcon
   */
  public showHideIcon() {
    this.showHide = !this.showHide;
  }
  /**
   * isRequired
   */
  public isRedirectionMediumRequired = () :boolean =>  {
    let result : boolean = true;
    switch(this.parentCmp && this.parentCmp.toLowerCase()){
      case 'salesorder' : result = false; break;
    }
    return result;
  }
  /**
   * recordSelected
   */
  public recordFromRadioSelection = (e : any) => {
    this.clientMachineSelected = [];
    this.clientMachineSelected.push(e);
  }
  /**
   * fetchPatchUrl
   */
  public fetchPatchUrl = () : string => {
    let url : string = `${endPoints.baseUrl}/`;
    switch(this.parentCmp && this.parentCmp.toLowerCase()){
      case 'salesorder' : url = url + `${endPoints.urlPath.reassignSo}`; break;
      case 'productionorder' : url = url + `${endPoints.urlPath.reassignPo}`;break;
      case 'podetails' : url = url + `${endPoints.urlPath.productionItems}` ; break;
    }
    return url;
  }
  /**
   * fetch existing medium
   */
  public fetchExistingMedium = (medium : string,dataIndex : string) : string =>  {
    let result : string ;
    let ary : any = [];
    let existingMediumInfo : any ;
    switch(medium.toLocaleLowerCase()){
      case 'satellite' : ary = this.satellites;existingMediumInfo = this.existingSatellite;break;
      case 'clientmachine' : ary = this.clientMachine;existingMediumInfo = this.clientMachineId;break; 
    }
    let id : string = existingMediumInfo;
    if(Array.isArray(existingMediumInfo) && existingMediumInfo.length > 1 && medium.toLocaleLowerCase() == "clientmachine"){
      return '';
    }else if(Array.isArray(existingMediumInfo) && medium.toLocaleLowerCase() == "clientmachine"){
      id= existingMediumInfo[0] && existingMediumInfo[0].id ? existingMediumInfo[0].id : existingMediumInfo[0] ;
    }
    let index : number = this.utils.fetchObjectFromAnArray(ary,{id:Number(id)},'id');
    result = ary[index] ? ary[index][dataIndex] : '';
    return result;
  }
  /**
   * checkForExistingClientMachine
   */
  public checkForExistingClientMachine = (id : string) : boolean=> {
    let result = true;
    this.clientMachineId.forEach((item) => {
      let cmId = item && item.id ? item.id : item;
      (cmId === id) ? result = false : ''
    });
    return result;
  }

  public displayNoClientManager = () : boolean => {
    let result = false;
    if(this.clientMachineId.length === 0){
      result = true;
    }else{
      let count = 0;
      this.clientMachine.forEach((item) => {
        this.clientMachineId.forEach((cm) => {
          let cmId = cm && cm.id ? cm.id : cm;
          (cmId === item.id) ? count ++ : '';
        });
      });
      result = count === this.clientMachine.length;
    }
    return result;
  }
}
