import { Component, OnInit } from '@angular/core';
import { OrderConfig, OrderFiltersConfig, GridConfig, MOrderConfig } from '../../shared/models/index';
import { endPoints } from '../../shared/constants/index';
import { OrderListService, UtilsService } from '../../shared/services/index';
import { ViewEncapsulation } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ModalComponent } from '../../shared/components/index';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TranslateService } from "@ngx-translate/core";
@Component({
  selector: 'app-sales-order',
  encapsulation: ViewEncapsulation.Emulated,
  templateUrl: './sales-order.component.html',
  styleUrls: ['./sales-order.component.scss']
})
export class SalesOrderComponent implements OnInit {
  public redirectView: boolean = false;
  public refeshData: boolean = false;
  public redirectSelectedArray: any = [];
  public selectedKey: string = "orderId";
  public selectedString = "Selected Sales Orders";
  public redirectHeaderText = "Redirect Sales Orders";
  public defaultFilter = "status";
  public defaultFilterValue = "queued";
  public responseKey = "salesOrders";
  public parentCmp: string = "salesorder";
  public modalRef: BsModalRef;
  constructor(private _translate: TranslateService,private listService: OrderListService, public router: Router, private modalService: BsModalService, private http: HttpClient, private utils: UtilsService) { }

  ngOnInit() {
    this.listService.config = this.salesOrderConfig();
  }
  /**
   * salesOrderConfig 
   */
  public salesOrderConfig = () => {
    let config: any;
    config = new OrderConfig('Generate PO',
      this._translate.instant('search'),
      'Redirect',
      [10, 20, 30],
      [new OrderFiltersConfig('I', 'text', [], 'form-group col-sm-3 col-md-4 col-lg-2', this._translate.instant('SALES_ORDER.sales_order_id'), this._translate.instant('SALES_ORDER.soid'), 'orderId', 'form-control '),
      new OrderFiltersConfig('I', 'number', [], 'form-group col-sm-3 col-md-4 col-lg-2', this._translate.instant('SALES_ORDER.volume'), this._translate.instant('SALES_ORDER.from'), 'volumeFrom', 'form-control'),
      new OrderFiltersConfig('I', 'number', [], 'form-group col-sm-3 col-md-4 col-lg-2', ' ', 'to', 'volumeTo', 'form-control'),
      new OrderFiltersConfig('I', 'text', [], 'form-group col-sm-3 col-md-4 col-lg-2', this._translate.instant('SALES_ORDER.delivery_date'), 'from', 'fromDate', 'form-control'),
      new OrderFiltersConfig('I', 'text', [], 'form-group col-sm-3 col-md-4 col-lg-2', ' ', 'to', 'toDate', 'form-control '),
      new OrderFiltersConfig('S', 'options', this.fetchStatusOptions(), 'form-group col-sm-3 col-md-4 col-lg-2', this._translate.instant('SALES_ORDER.status'), 'status', 'status', 'form-control')],
      [new GridConfig('orderId', this._translate.instant('SALES_ORDER.sales_order_id'), true, false),
      new GridConfig('volume', this._translate.instant('SALES_ORDER.volume'), true, false),
      new GridConfig('deliveryDate', this._translate.instant('SALES_ORDER.delivery_date'), true, false),
      new GridConfig('status', this._translate.instant('SALES_ORDER.status_of_order'), true, false)],
      `${endPoints.baseUrl}/${endPoints.urlPath.salesOrder}`,
      [new MOrderConfig('orderId', 'ID',false), new MOrderConfig('status', 'Status',false), new MOrderConfig('volume', 'Volume',false), new MOrderConfig('deliveryDate', 'Delivery Date',false)],
      (...arg) => { return arg[0].status.toLowerCase() != "queued" && arg[0].status.toLowerCase() != "failed"},
      "GET"
    );
    return config;
  }
  /**
   * onRedirect
   */
  public onRedirect = (selectedEl: any) => {
    this.redirectView = true;
    this.redirectSelectedArray = selectedEl;
  }
  /**
   * onCancel 
   */
  public onCancel = () => {
    this.redirectView = false;
  }
  /**
   * redirectTrigger
   */
  public redirectTrigger = () => {
    this.redirectView = false;
    this.refeshData = !this.refeshData;
  }
  /**
   * fetchStatusOptions
   */
  public fetchStatusOptions = (): any => {
    let result: any = [];
    result.push({
      key: this._translate.instant('SALES_ORDER.received_key'), value: this._translate.instant('SALES_ORDER.received')
    }, {
        key: this._translate.instant('SALES_ORDER.verified_key'), value: this._translate.instant('SALES_ORDER.verified')
      }, {
        key: this._translate.instant('SALES_ORDER.queued_key'), value: this._translate.instant('SALES_ORDER.queued')
      }, {
        key: this._translate.instant('SALES_ORDER.production_orders_generated_key'), value:  this._translate.instant('SALES_ORDER.production_orders_generated')
      }, {
        key: this._translate.instant('SALES_ORDER.under_process_key'), value: this._translate.instant('SALES_ORDER.under_process')
      }, {
        key: this._translate.instant('SALES_ORDER.completed_key'), value: this._translate.instant('SALES_ORDER.completed')
      }, {
        key: this._translate.instant('SALES_ORDER.failed_key'), value: this._translate.instant('SALES_ORDER.failed')
      }, {
        key: this._translate.instant('SALES_ORDER.shipped_key'), value: this._translate.instant('SALES_ORDER.shipped')
      });
    return result;

  }
  /**
   * personalizPO
   */
  public personalizPO = (selectedEl: any) => {
    this.listService.salesOrder = this.utils.returnNewArrayFromExistingArray(selectedEl, (item, index) => { return item['orderId'] });
    this.router.navigate(['production-order']);
  }
  /**
   * fetchOrderIdFromSelected
   */
  public fetchOrderIdFromSelected = (item: any, index: number): any => {
    return item['orderId'];
  }
  /**
   * showModalPopup
   */
  // public showModalPopup = (result: boolean, showAnchor: boolean) => {
  // //   this.modalRef = this.modalService.show(ModalComponent, { ignoreBackdropClick: true, keyboard: false });
  // //   this.modalRef.content.modalMessage = result ? "To see the newly generated PO's" : "Error have occured";
  // //   this.modalRef.content.headerMsg = result ? 'Success' : 'Failure';
  // //   this.modalRef.content.enableCancelBtn = false;
  // //   this.modalRef.content.enableSuccessBtn = true;
  // //   this.modalRef.content.successButtonText = 'Ok';
  // //   this.modalRef.content.cancelButtonTxt = '';
  // //   this.modalRef.content.anchorVisible = showAnchor;
  // //   this.modalRef.content.anchorClick.subscribe(() => {
  // //     this.router.navigate(['production-order']);
  // //   });
  // // }
}
