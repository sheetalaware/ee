import {ArrayFilterPipe} from './card-filter.pipe';

export const SharedFilter = [ArrayFilterPipe];

export * from './card-filter.pipe';